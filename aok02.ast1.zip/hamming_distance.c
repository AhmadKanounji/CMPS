#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int XORoperation(int numOne,int numTwo);
void Intro();

int main()
{
    int stop=0;
    while(stop !=-1)
    {
        Intro();
        printf("\nWould you like to stop?(-1): ");
        scanf("%d",stop);
        printf("%d",&stop);
    }
    return 0;
}

void Intro()
{
    int firstNumber;
    int secondNumber;
   
    printf("Enter a pair positive integers: ");
    scanf("%d %d",&firstNumber,&secondNumber);
    while(firstNumber<0 || secondNumber<0)
    {
        if(firstNumber<0 && secondNumber<0)
        {
            printf("Please change both integers to positive ones: ");
            scanf("%d %d", &firstNumber,&secondNumber);
        }
        if(firstNumber<0)
        {
            printf("Please change first integer to a positive one: ");
            scanf("%d",&firstNumber); 
        }
        if(secondNumber<0)
        {
            printf("Please change second integer to a positive one: ");
            scanf("%d",&secondNumber);    
        }
    }
        // In the previous lines(23-->45),we took 2 integers from the user and tested the cases in which the integers given are not positive,
        // in the case where the integer is negative we asked him to re-enter another integer that was positive, and continued 
        // the algorithm when he did so.
        int Hamming =XORoperation(firstNumber,secondNumber);
    return 0;
}
int XORoperation(int numOne,int numTwo)
{
    int i;
    int j;
    int a[32];
    int b[32];
    for(i=0;i<32;i++)    
    {    
        a[i]=numOne%2;    
        numOne=numOne/2;
    }
    for(j=0;j<32;j++)    
    {    
        b[j]=numTwo%2;    
        numTwo=numTwo/2;
    }
    // In the previous lines(53-->66), we iterated over each number of the integer's given by the user, applied a certain method 
    // that turned them into binary numbers and stored them in int arrays a and b respectfully for int numberOne and int numberTwo. 
    printf("\nBinary of First Number is= ");    
    for(i=i-1;i>=0;i--)    
    {    
        printf("%d",a[i]);    
    }
    printf("\nBinary of Second Number is=");    
    for(j=j-1;j>=0;j--)    
    {    
        printf("%d",b[j]);    
    }
    // In the previous lines(69-->78), we iterated over arrays a and b to display for the user the result of the binary conversion.
    int Hamming=0;
    int k;
    for(k=32;k>=0;k--)
    {
        if((a[k]==1 && b[k]==0) || (a[k]==0 && b[k]==1))
        {
            Hamming++;
        }
    }
    
    printf("\nHamming Distance is equal to :%d",Hamming);
    // In the previous lines(80-->90), we iterated over arrays a and b simultaneously and performed a XOR operation(to check if a[k]!=b[k]), 
    // and each time that was the case we added 1 to the hamming distance stored in the Hamming variable, we lastly print the distance to the user.
    return Hamming;
}

//Ahmad Kanounji / 202204402
