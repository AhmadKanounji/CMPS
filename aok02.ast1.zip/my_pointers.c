#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

void sort(char *array[], int size)
{
   //Function do sort the merged array later in the merge function using bubble sort:
   char temp[30];
   for(int i=0; i<size; i++)
   {
      for(int j=0; j<size-1-i; j++)
      {
         if(strcmp(array[j], array[j+1]) > 0)
         {
            //swap array[j] and array[j+1]
            strcpy(temp, array[j]);
            strcpy(array[j], array[j+1]);
            strcpy(array[j+1], temp);
         }
      }
   }
}

char ** merge(char *arrOne[],char *arrTwo[],int nbOfStringsOne ,int nbofStringsTwo)
{
   // Number of Strings in Both Arrays
   int mergedN = nbOfStringsOne+nbofStringsTwo;
   // Initialising merged array and allocating the necessary memory to it
   char ** a = (char **)malloc(sizeof(char *)* mergedN);
   //
   int i;
   // Allocating memory in merged array for elements of array one
   for (i = 0; i < nbOfStringsOne; i++)
   {
      a[i] = (char*)malloc(sizeof(char)* (strlen(arrOne[i])+1));
   }
   //
   int k=i;
   // Storing the elements from Array One in merged Array
   for(int i=0;i<nbOfStringsOne;i++)
   {
      for(int j=0;j<strlen(arrOne[i]);j++)
      {
         a[i][j]=arrOne[i][j];
      }
   }
   // Allocating memory in merged array for elements of array two
    for (int i = 0; k < mergedN; i++)
   {
      a[k] = (char*)malloc(sizeof(char)* (strlen(arrTwo[i])+1));
      k++;
   }
   //
   int z=nbOfStringsOne;
   // Storing the elements from Array two in merged Array
   for(int i=0;z<mergedN;i++)
   {
      for(int j=0;j<strlen(arrTwo[i]);j++)
      {
         a[z][j]=arrTwo[i][j];
      }
      z++;
   }
   // Printing merged array before sorting
   printf("Merged Array before sorting:\n");
   for(int i=0;i<mergedN;i++)
   {
      for(int j=0;j<strlen(a[i])-2;j++)
      {
         printf("%c",a[i][j]);
      }
      printf("\n");
   }
   // Sorting merged array then printing it
   sort(a,mergedN);
   printf("Merged Array after sorting:\n");
    for(int i=0;i<mergedN;i++)
   {
      for(int j=0;j<strlen(a[i])-2;j++)
      {
         printf("%c",a[i][j]);
      }
      printf("\n");
   }
   return a;
}

int main()
{
   // Array One
   char * arrOne[] = { "1","5","6" };
   // Array Two
   char * arrTwo[] = { "2","3" };
   // Number of Strings in Array One
   int n = sizeof(arrOne)/sizeof(arrOne[0]);
   // Number of Strings in Array Two
   int n2 = sizeof(arrTwo)/sizeof(arrTwo[0]);
   //
   char ** mergedArr= merge(arrOne,arrTwo,n,n2);
   
   return 0;
}