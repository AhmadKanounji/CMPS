#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>


int main()
{
    char  *arr[2][3] = {{"I","Love","Sparta"},{"I","Hate","Coding"}};

    int nbOfStrings =sizeof(arr)/sizeof(arr[0]); //2

    int nbOfSubStrings =sizeof(arr[0])/sizeof(arr[0][0]); //3
    
    char *concArr[2];

    for(int i=0;i<nbOfStrings;i++)
    {
        for(int j=0;j<nbOfSubStrings;j++)
        {
            strcat(concArr[i],arr[i][j]);
        }
    }
    for(int i=0;i<sizeof(concArr);i++)
    {
        printf("%s\n",concArr[i]);
    }

    return 0;
}