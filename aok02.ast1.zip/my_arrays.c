#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

const int size =10;

void printArray(int arr[])
{
    int i;
    for(i=-1;i<size;i++)
    {
        if(i==-1)
        {
            printf("Index   Value\n");
        }
        else
        printf("    %d       %d\n",i,arr[i]);
    }
}

void arrayHistogram(int arr[])
{
    int oneCounter=0;
    int twoCounter=0;
    int threeCounter=0;
    for(int i=-1;i<size;i++)
    {
        if(arr[i]==1)
        {
            oneCounter++;
        }
        else if(arr[i]==2)
        {
            twoCounter++;
        }
        else
        {
            threeCounter++;
        }
    }
    // Initialising 3 counters for each digit(1,2,3), then iterating over the array to increment the counters so we can display the frequency
    // and the histogram later in the algorithm
    char oneHisto[oneCounter];
    char twoHisto[twoCounter];
    char threeHisto[threeCounter];
    for(int i=0;i<oneCounter;i++)
    {
        oneHisto[i]='*';
    }
    oneHisto[oneCounter] = '\0';
    for(int i=0;i<twoCounter;i++)
    {
        twoHisto[i]='*';
    }
    twoHisto[twoCounter] = '\0';
    for(int i=0;i<threeCounter;i++)
    {
        threeHisto[i]='*';
    }
    threeHisto[threeCounter] = '\0';
    
    printf("Value   Frequency   Histogram\n");
    for(int j=0;j<3;j++)
    {
        if(j==0)
        printf("    %d           %d        %s\n",1,oneCounter,oneHisto);
        else if(j==1)
        printf("    %d           %d        %s\n",2,twoCounter,twoHisto);
        else
        printf("    %d           %d        %s\n",3,threeCounter,threeHisto);
    }
}

void swapValues(int posOne,int posTwo,int arr[])
{
    int temp;
    
    if(posOne>size-1 || posTwo>size-1 || posOne<0 || posTwo<0)
    {
        if(posOne >size-1)
        {
            printf("First index bigger than array size\n");
        }
        if(posOne<0)
        {
            printf("First index smaller than 0\n");
        }
        if(posTwo>size-1)
        { 
            printf("Second index bigger than array size\n");
        }
        if(posTwo<0)
        { 
            printf("Second index smaller than 0\n");
        }
    }
    //Setting up the conditions that will result in an error due to one of the indices being out of bounds(bigger than array size or smaller than 0)
    else
    {
        if(posOne == posTwo )
        {
            printf("No changes will occur since same index for posOne and posTwo\n");
        }
        // In case the user did not go out of bounds but has inserted the same index for both positions, do nothing and display that the array
        // will incur no changes.
        else
        {
            temp= arr[posOne];
            arr[posOne]=arr[posTwo];
            arr[posTwo]=temp;
        }
        // In case the user did not go out of bounds and has not inserted the same index for both positions swap the value corresponding to the
        // indices given by the user.
    }
}

 void bubbleSort(int array[]) 
 {
  for (int i = 0; i < size - 1; ++i) 
  {
    for (int j = 0; j < size - i - 1; ++j) 
    {
      if (array[j] > array[j + 1]) 
      {  
        swapValues(j,j+1,array);
      }
    }
  }
  // Starting from the first index, compare the first and the second elements, if the first element is greater than the second element, 
  // they are swapped.We then compare the second and the third elements and swap them if they are not in order.
  // The above process goes on until the last element.

}

int median(int arr[])
{
    bubbleSort(arr);
    int median = ((arr[size/2])+(arr[size/2-1]))/2; // since we have 10 elements --> even
    return median;
    // Knowing that the array is composed of 10 elements(even number) the median is equal to the mean of the two middle values of the array
}

int mode(int arr[])
{
    int oneCounter=0;
    int twoCounter=0;
    int threeCounter=0;
    for(int i=0;i<size;i++)
    {
        if(arr[i]==1)
        {
            oneCounter++;
        }
        else if(arr[i]==2)
        {
            twoCounter++;
        }
        else
        {
            threeCounter++;
        }
    }
    // We once again use the counters for each digit we had previously used in a for loop that iterates over the array
    if(oneCounter>twoCounter && oneCounter>threeCounter)
    {
        return 1;
    }
    else if(twoCounter>oneCounter && twoCounter>threeCounter)
    {
        return 2;
    }
    else
    {
        return 3;
    }
    // We then check which of the counters has the greatest value by comparing them to each other, we could have inserted the values in a
    // for loop and iterated over them to check the biggest value but both ways work.
}

int isSorted(int arr[])
{
    bool isSorted =true;
    for(int i=0;i<size-1;i++)
    {
        if(arr[i]<=arr[i+1])
        {
            isSorted=true;
        }
        else
        {
            isSorted=false;
            break;
        }
    }
    if(isSorted==true)
    return 1;
    else
    return 0;
    // We initiated a boolean isSorted to true and iterated over the given array, we then compared the value at index i with its succesor
    // at i+1, if arr[i]<=arr[i+1] then the bool isSorted remains true and the process keeps on going till arr[i]>arr[i+1] indicating that the
    // array is not sorted which leads us to set the bool isSorted to false. At last if the bool isSorted is true return 1, else return 0.
}

int main()
{
    int arr[10]={1,2,3,1,2,3,1,2,3,1};
    arr[10] = '\0';
    // printArray(arr);
    // arrayHistogram(arr);
    // swapValues(3,4,arr);
    // printArray(arr);
    // bubbleSort(arr);
    // printArray(arr);
    // printf("%d",median(arr));
    // int modeValue = mode(arr);
    // printf("%d",modeValue);
    // int isSortedValue = isSorted(arr);
    // printf("%d",isSortedValue);
    return 0;
}

// Ahmad Kanounji 202204402