#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int printBinary(unsigned int num)
{
    int i;
    int numb=num;
    int a[32];
    for(i=0;i<32;i++)    
    {    
        a[i]=num%2;    
        num=num/2;
    }
    printf("\nBinary of given number (%d) is=",numb);    
    for(i=i-1;i>=0;i--)    
    {    
        printf("%d",a[i]);    
    }
}
// In lines(5-->20), the function printBinary prints the binary version of the integer given by the user.

int bitCounter(unsigned int num)
{
    int i;
    int a[32];
    for(i=0;i<32;i++)    
    {    
        a[i]=num%2;    
        num=num/2;
    }
    int k;
    int bitCount=0;
    for(k=0;k<32;k++)
    {
        if(a[k]==1)
        {
            bitCount++;;
        }
    }
    
    return bitCount;
}
// In lines(23-->43), the function bitCounter returns how many 1 bits are found in the binary version of the given integer, in case 
// only one 1 is found, we can instantly claim that both the MSBit and LSBit have the same positon, instead of using both msb and lsb functions. 

int msb(unsigned int num)
{
    int i;
    int numb=num;
    int a[32];
    for(i=0;i<32;i++)    
    {    
        a[i]=num%2;    
        num=num/2;
    }
    int k;
    int position;
    for(k=0;k<32;k++)
    {
        if(a[k]==1)
        {
            position=k;
        }
    }
    return position;
}
// In lines(47-->67), the function msb allows us to find the most significant bit of the binary version of an integer by iterating 
// over the binary version and keeps on updating the variable "position" to where the latest 1 wast found.

int lsb(unsigned int num)
{
    int i;
    int numb =num;
    int a[32];
    for(i=0;i<32;i++)    
    {    
        a[i]=num%2;    
        num=num/2;
    }  
    int k;
    int position;
    for(k=0;k<32;k++)
    {
        if(a[k]==1)
        {
            position=k;
            break;
        }
    }
    return position;
}
// In lines(71-->92), the function lsb allows us to find the least significant bit of the binary version of an integer by iterating 
// over the binary version and setting the variable "position" to where the first 1 wast found and instantly stopping the loop.

int main()
{
    int num;
    printf("Please enter a positive non zero integer: ");
    scanf("%d",&num);
    printBinary(num);
    if(bitCounter(num)==1)
    {
        printf("\nThe index of both the most and least significant bit set to 1 is: %d",msb(num));
        printf("\nThe distance between the MSBit and LSBit is equal to 0");
    }
    else
    {
        printf("\nThe index of the most significant bit set to 1 is: %d",msb(num));
        printf("\nThe index of the least significant bit set to 1 is: %d",lsb(num));
        int distance=msb(num)-lsb(num);
        printf("\nThe distance between the MSBit and LSBit is equal to %d",distance);
    }
    return 0;
}

// Ahmad Kanounji/ 202204402