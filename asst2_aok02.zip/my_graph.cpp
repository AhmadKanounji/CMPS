#include <stdexcept>
#include <map>
#include <list>
#include <vector>
#include <iostream>

using namespace std;

class my_graph 
{
    protected:
    map <int , vector <int > > outgo;

    public:

    my_graph (const vector <int > & startP, const vector <int > & endP)
    {
        if(startP.size() != endP.size())
        {
            throw invalid_argument (" The starting and ending point lists do not have the same length");
        }
        for(unsigned i=0;i<startP.size (); i++) 
        {
            int start = startP [i], end = endP [i];
            outgo [start].push_back(end);
            outgo [end]; 
        }
    }

    void addEdge(int one, int two)
    {
        outgo.at(one).push_back(two);
    }
    
    int numOutgoing(const int nodeID) const 
    {
        return adjacent(nodeID).size();
    };
    
    const vector<int> & adjacent(const int nodeID) const 
    {
        map <int , vector <int > >:: const_iterator iter = outgo . find ( nodeID );
        if(iter==outgo.end()) 
        {
            throw invalid_argument (" Invalid node ID");
        }
        return iter->second;
    };

    bool isCyclicUtil(int x, bool vis[], bool *recStack)
    {
        if(vis[x]==false)
        {
            vis[x] = true;
            recStack[x] = true;
            vector<int>::iterator iter;
            for (iter = outgo.at(x).begin(); iter != outgo.at(x).end(); ++iter)
            {
                if (!vis[*iter] && isCyclicUtil(*iter, vis, recStack))
                    return true;
                else if (recStack[*iter])
                    return true;
            }
        }
        recStack[x] = false;  
        return false;
    };

    bool isCyclic()
    {
        int x = outgo.size();
        bool *vis = new bool[x];
        bool *recStack = new bool[x];
        for(int iter = 0; iter < x; iter++)
        {
            vis[iter] = false;
            recStack[iter] = false;
        }
        for(int i = 0; i < x; i++)
            if (!vis[i] && isCyclicUtil(i, vis, recStack))
                return true;
        return false;
    }; 
};

int main()
{
    vector<int> vecOne;
    vecOne.push_back(0);
    vecOne.push_back(0);
    vecOne.push_back(0);
    vecOne.push_back(4);
    vecOne.push_back(4);
    vecOne.push_back(3);

    vector<int> vecTwo;
    vecTwo.push_back(1);
    vecTwo.push_back(2);
    vecTwo.push_back(3);
    vecTwo.push_back(3);
    vecTwo.push_back(1);
    vecTwo.push_back(1);

    my_graph graph = *(new my_graph(vecOne, vecTwo));
    graph.addEdge(1, 2);
    graph.addEdge(1, 4);
    graph.addEdge(2, 1);
    cout << graph.isCyclic() << endl;
    cout << graph.numOutgoing(1) << endl; 
}