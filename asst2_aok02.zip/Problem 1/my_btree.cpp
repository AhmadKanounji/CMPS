#include "BinaryTree.h"
#include <iostream>
using namespace std;

int main()
{
	BinaryTree<int> myTree;

	TreeNode<int> *tempRoot=myTree.getRoot();

	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(9));

	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(10));

	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(20));			
			
	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(35));

	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(8));

	tempRoot=myTree.addNode(tempRoot,new TreeNode<int>(1));

	cout << "Your tree contains " << myTree.treeSize() << " elements:" << endl;

	myTree.preOrderPrint(tempRoot);
	
	cout<<myTree.subTreeSize(tempRoot,9)<<endl;
	// myTree.deleteNode(tempRoot,35);
	
	// cout << "Your tree contains " << myTree.treeSize() << " elements:" << endl;

	// myTree.preOrderPrint(tempRoot);

	// myTree.deleteNode(tempRoot,10);

	// cout << "Your tree contains " << myTree.treeSize() << " elements:" << endl;

	// myTree.preOrderPrint(tempRoot);

	// myTree.deleteNode(tempRoot,8);

	// cout << "Your tree contains " << myTree.treeSize() << " elements:" << endl;

	// myTree.preOrderPrint(tempRoot);
	
}