#ifndef BINARYTREE_H
#define BINARYTREE_H
#include "TreeNode.h"
#include <bits/stdc++.h>
using namespace std;
template <typename T>
class BinaryTree
{
	private:
		TreeNode<T> *root;
		int numberOfElements;

	public:
		BinaryTree():root(nullptr),numberOfElements(0) {}

		~BinaryTree()
		{
			if(root!=nullptr)
			{
				delete root->leftChild;

				delete root->rightChild;
			}
		}
		// requires: the user to enter the root of his tree
		// effects: if the user's tree's root is null will return 0, other wise recurse the tree to return it's full height
		int height(TreeNode<T> *root)
		{
			if(root == NULL)
				return 0;
			else
			{
				int lheight = height(root->leftChild)+1;
				int rheight = height(root->rightChild)+1;

			return (lheight > rheight) ? lheight : rheight; //returns maximum height
			}
		}
		//requires: the user to enter the root of his tree
		//effects: if the user's tree's root is null will return 0, other wise recurse on the leftside of the tree and rightside of the tree to return the balance factor of the tree
		int bal(TreeNode<T> *root)
		{
			if(root == NULL)
				return 0;
			int lheight = height(root->leftChild)+1;
			int rheight = height(root->rightChild)+1;

			return (lheight - rheight); //[Balance Factor = Height of leftChild Sub-Tree - Height of rightChild Sub-Tree]
		}

		//requires: the user to enter the root of his tree
		//effects: return false if the root is null, other wise recurse on the tree's leftside and rightside to check if a subtree has a balance factor > 0
		bool check(TreeNode<T> *root)
		{
			//traversing the nodes of the subtree to check any node with balance factor > 0
			if(root == NULL)
				return false;
			bool x = check(root->leftChild);
				if(bal(root))
					return true;
			bool y = check(root->rightChild);

			return x||y;    //If any node present with balance factor > 0
		}

		//requires: the user to enter the root of the tree and the a new node with the data he would like to insert
		//effects:	if root is null will insert the new node at root, otherwise recurse until node can be inserted without breaking the balance factor at the heighest level of the tree
		TreeNode<T>* addNode(TreeNode<T> *root, TreeNode<T> *t)
		{
			if(root == NULL)
			{
				numberOfElements++;
				return t;
			}
        	
			else if(bal(root)==0 && check(root->rightChild))  //Condition to addNode node in the rightChild sub-tree
				root->rightChild = addNode(root->rightChild,t);
			
			else if(bal(root)==0)                      //condition to addNode node in the leftChild sub-tree
				root->leftChild = addNode(root->leftChild,t);
			
			else if(bal(root)==1 && check(root->leftChild))   //condition to addNode node in the leftChild sub-tree
				root->leftChild = addNode(root->leftChild,t);
			
			else if(bal(root)==1)
				root->rightChild = addNode(root->rightChild,t);      //condition to addNode node in rightChild sub-tree
			
			return root;
		}
		//requires: the user to enter the root of the tree and the data he would like to delete
		//effects: will delete the node with the data entered if it is a leaf node with no children, otherwise will print "Cannot delete node" 
		TreeNode<T>* deleteNode(TreeNode<T> *root,const T Data)
		{
			if (root == NULL)
        		return nullptr;
			root->leftChild = deleteNode(root->leftChild, Data);
			root->rightChild = deleteNode(root->rightChild, Data);

			if (root->data == Data && root->leftChild == NULL && root->rightChild == NULL) 
			{
				numberOfElements--;
				return nullptr;
			}
			else if(root->data==Data && (root->leftChild== NULL || root->rightChild ==NULL))
			{
				cout<<"Cannot Delete Node"<<endl;
			}
			return root;
		}

		TreeNode<T>* getRoot() const
		{
			return root;
		}
		//requires: nothing
		//effects: returns the number of nodes in the tree
		int treeSize() const
		{
			return numberOfElements;
		}

		int subTreeSize(TreeNode<T> *root,const T key)
		{
			if(root==nullptr)
			{
				return 0;
			}
			else if(root->data==key)
			{
				int lheight = height(root->leftChild)+1;
				int rheight = height(root->rightChild)+1;
				return (lheight > rheight) ? lheight : rheight;
			}
			else 
			{
				subTreeSize(root->leftChild,key);
				subTreeSize(root->rightChild,key);
			}
			
		}

		void preOrderPrint(TreeNode<T> *root) const
		{
			if(root!=nullptr)
			{
				std::cout << root->data << std::endl;

				preOrderPrint(root->leftChild);

				preOrderPrint(root->rightChild);
			}
		}

		void inOrderPrint(TreeNode<T>* root) const
		{
			if(root!=nullptr)
			{
				inOrderPrint(root->leftChild);

				std::cout << root->data << std::endl;

				inOrderPrint(root->rightChild);
			}
		}

		void postOrderPrint(TreeNode<T> *root) const
		{
			if(root!=nullptr)
			{
				postOrderPrint(root->leftChild);

				postOrderPrint(root->rightChild);

				std::cout << root->data << std::endl;
			}
		}
};
#endif