#ifndef TreeNode_H
#define TreeNode_H
#include <iostream>
#include <cstdlib>

//forward delcration since BinaryTree needs access to the private data members of TreeNode class
template <typename T>
class BinaryTree;

template <typename T>
class TreeNode
{
	friend class BinaryTree<T>;
	private:
		TreeNode *leftChild;
		TreeNode *rightChild;
		T data;
	public:
		TreeNode(const T Data):data(Data),rightChild(nullptr),leftChild(nullptr) 
		{
			
		}

		T getData() const
		{
			return data;
		}

		TreeNode* getRightChild() const
		{
			return rightChild;
		}

		TreeNode* getLeftChild() const
		{
			return leftChild;
		}
};
#endif