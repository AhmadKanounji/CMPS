#include <list>

using namespace std;

template <typename T> class my_stack
{
    public:
    my_stack() {}

    bool empty()
    {
        return list.empty();
    }

    void push(const T &key)
    {
        list.push_back(key);
    }

    T& top()
    {
        return list.back();
    }

    void pop()
    {
        list.pop_back;
    }

    my_stack<T> operator+(my_stack<T> stack)
    {
        my_stack<T> stackTwo;
        for(int i=0;i<list.size();i++)
        {
            T cur = list.front();
            list.pop_pront();
            stackTwo.push(cur);
            list.push_back(cur);
        }
        for(int i=0;i<stack.list.size();i++)
        {
            T cur = stack.list.front();
            stack.list.pop_pront();
            stackTwo.push(cur);
            stack.list.push_back(cur);
        }
        return stackTwo;
    }
    private:
    list<T> list;
};